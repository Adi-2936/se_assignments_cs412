"""Flappy Bird game package."""
